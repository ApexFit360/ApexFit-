import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, SafeAreaView, StyleSheet, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ACC } from './src/theme';
import { DEFAULTS } from './src/data';
import { setupNotifications, scheduleAll } from './src/notifications';
import RemindersScreen from './src/screens/RemindersScreen';
import DishesScreen from './src/screens/DishesScreen';

const KEY = 'apexfit_items';

export default function App() {
  const [tab, setTab] = useState('rem');
  const [items, setItems] = useState(null);

  useEffect(() => {
    (async () => {
      await setupNotifications();
      try {
        const s = await AsyncStorage.getItem(KEY);
        setItems(s ? JSON.parse(s) : DEFAULTS);
      } catch (e) {
        setItems(DEFAULTS);
      }
    })();
  }, []);

  useEffect(() => {
    if (!items) return;
    AsyncStorage.setItem(KEY, JSON.stringify(items)).catch(() => {});
    scheduleAll(items).catch(() => {});
  }, [items]);

  if (!items) return <SafeAreaView style={s.root}><Text style={s.h1}>Loading…</Text></SafeAreaView>;
  const sorted = [...items].sort((a, b) => (a.t < b.t ? -1 : 1));

  return (
    <SafeAreaView style={s.root}>
      <Text style={s.h1}>Apex<Text style={{ color: ACC }}>Fit</Text></Text>
      <View style={s.tabs}>
        {[['rem', 'Reminders'], ['dish', 'Indian Dishes']].map(([k, n]) => (
          <TouchableOpacity key={k} style={[s.tab, tab === k && s.tabOn]} onPress={() => setTab(k)}>
            <Text style={{ color: tab === k ? '#fff' : '#333', fontWeight: '700' }}>{n}</Text>
          </TouchableOpacity>
        ))}
      </View>
      {tab === 'rem' ? <RemindersScreen items={sorted} setItems={setItems} /> : <DishesScreen />}
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#f5f6fa', paddingTop: Platform.OS === 'android' ? 36 : 0 },
  h1: { fontSize: 28, fontWeight: '800', marginHorizontal: 16, marginVertical: 8 },
  tabs: { flexDirection: 'row', marginHorizontal: 12, gap: 8 },
  tab: { flex: 1, padding: 10, borderRadius: 10, backgroundColor: '#e5e7eb', alignItems: 'center' },
  tabOn: { backgroundColor: ACC },
});
