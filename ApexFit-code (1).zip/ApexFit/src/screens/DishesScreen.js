import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { ACC } from '../theme';
import { DISHES } from '../data';

export default function DishesScreen() {
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(null);
  const list = DISHES.filter(d => d[0].toLowerCase().includes(q.toLowerCase().trim()));

  return (
    <View style={{ flex: 1 }}>
      <TextInput style={s.in} placeholder="Search a dish…" value={q} onChangeText={setQ} />
      {sel && (
        <View style={s.res}>
          <Text style={{ fontSize: 16 }}>{sel[0]} ({sel[1]})</Text>
          <Text style={{ fontSize: 24, fontWeight: '800', color: ACC }}>{sel[2]} kcal</Text>
          <Text>Protein {sel[3]} g</Text>
        </View>
      )}
      <FlatList
        data={list}
        keyExtractor={d => d[0]}
        renderItem={({ item }) => (
          <TouchableOpacity style={s.row} onPress={() => setSel(item)}>
            <Text style={{ flex: 1 }}>{item[0]}</Text>
            <Text style={{ color: '#888' }}>{item[1]}</Text>
          </TouchableOpacity>
        )}
      />
      <Text style={s.note}>Calories are approximate and vary with ghee/oil used.</Text>
    </View>
  );
}

const s = StyleSheet.create({
  in: { backgroundColor: '#fff', borderRadius: 10, padding: 10, borderWidth: 1, borderColor: '#e5e7eb', margin: 12 },
  row: { flexDirection: 'row', alignItems: 'center', padding: 14, marginHorizontal: 12, marginTop: 8, backgroundColor: '#fff', borderRadius: 12 },
  res: { backgroundColor: '#fff', marginHorizontal: 12, padding: 14, borderRadius: 12, borderWidth: 2, borderColor: ACC },
  note: { textAlign: 'center', color: '#888', padding: 8, fontSize: 12 },
});
