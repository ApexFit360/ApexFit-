import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, Switch, StyleSheet, SafeAreaView, Platform, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false }),
});

const KEY = 'apexfit_items';
const DEFAULTS = [
  { id: '1', t: '06:30', l: 'Wake up and drink water', on: true },
  { id: '2', t: '07:00', l: 'Workout time', on: true },
  { id: '3', t: '09:00', l: 'Healthy breakfast', on: true },
  { id: '4', t: '13:00', l: 'Protein-rich lunch', on: true },
  { id: '5', t: '17:30', l: 'Walk and stretching', on: true },
  { id: '6', t: '22:30', l: 'Wind down for sleep', on: true },
];
// [name, serving, kcal, protein g]
const DISHES = [
  ['Roti','1 medium',100,3],['Plain Paratha','1',260,5],['Aloo Paratha','1',300,6],['Rice (Chawal)','1 bowl',195,4],
  ['Dal Tadka','1 bowl',150,7],['Rajma','1 bowl',190,9],['Chole','1 bowl',210,9],['Paneer Butter Masala','1 bowl',300,12],
  ['Palak Paneer','1 bowl',230,11],['Chicken Curry','1 bowl',250,22],['Butter Chicken','1 bowl',300,20],
  ['Chicken Biryani','1 plate',450,20],['Veg Biryani','1 plate',350,8],['Idli','2 pcs',120,4],['Plain Dosa','1',130,3],
  ['Masala Dosa','1',250,5],['Sambar','1 bowl',90,4],['Poha','1 plate',250,5],['Upma','1 plate',230,5],['Samosa','1',260,4],
  ['Pav Bhaji','1 plate',400,9],['Vada Pav','1',290,6],['Chole Bhature','1 plate',450,12],['Dhokla','2 pcs',120,4],
  ['Khichdi','1 bowl',180,6],['Curd (Dahi)','1 bowl',90,4],['Kadhi','1 bowl',150,5],['Aloo Gobi','1 bowl',150,3],
  ['Bhindi Masala','1 bowl',120,3],['Egg Bhurji','2 eggs',200,12],['Besan Chilla','1',130,6],['Gulab Jamun','1',150,2],
  ['Jalebi','50 g',220,1],['Sweet Lassi','1 glass',200,6],['Sugar Tea (Chai)','1 cup',80,2],
];

async function schedule(items) {
  await Notifications.cancelAllScheduledNotificationsAsync();
  for (const r of items) {
    if (!r.on) continue;
    const [h, m] = r.t.split(':').map(Number);
    await Notifications.scheduleNotificationAsync({
      content: { title: 'ApexFit', body: r.l, sound: true },
      trigger: { hour: h, minute: m, repeats: true, channelId: 'reminders' },
    });
  }
}

export default function App() {
  const [tab, setTab] = useState('rem');
  const [items, setItems] = useState(null);
  const [nt, setNt] = useState('');
  const [nl, setNl] = useState('');
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(null);

  useEffect(() => {
    (async () => {
      if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('reminders', {
          name: 'Reminders', importance: Notifications.AndroidImportance.HIGH, vibrationPattern: [0, 250, 250, 250],
        });
      }
      await Notifications.requestPermissionsAsync();
      try {
        const s = await AsyncStorage.getItem(KEY);
        setItems(s ? JSON.parse(s) : DEFAULTS);
      } catch (e) { setItems(DEFAULTS); }
    })();
  }, []);

  useEffect(() => {
    if (!items) return;
    items.sort((a, b) => (a.t < b.t ? -1 : 1));
    AsyncStorage.setItem(KEY, JSON.stringify(items)).catch(() => {});
    schedule(items).catch(() => {});
  }, [items]);

  const add = () => {
    const ok = /^([01]?\d|2[0-3]):[0-5]\d$/.test(nt.trim());
    if (!ok || !nl.trim()) return Alert.alert('Invalid input', 'Use time like 18:30 and enter a name.');
    const [h, m] = nt.trim().split(':');
    setItems([...items, { id: String(Date.now()), t: h.padStart(2, '0') + ':' + m, l: nl.trim(), on: true }]);
    setNt(''); setNl('');
  };

  if (!items) return <SafeAreaView style={s.root}><Text style={s.h1}>Loading…</Text></SafeAreaView>;
  const dishes = DISHES.filter(d => d[0].toLowerCase().includes(q.toLowerCase().trim()));

  return (
    <SafeAreaView style={s.root}>
      <Text style={s.h1}>Apex<Text style={{ color: ACC }}>Fit</Text></Text>
      <View style={s.tabs}>
        {[['rem', 'Reminders'], ['dish', 'Indian Dishes']].map(([k, n]) => (
          <TouchableOpacity key={k} style={[s.tab, tab === k && s.tabOn]} onPress={() => setTab(k)}>
            <Text style={{ color: tab === k ? '#fff' : '#333', fontWeight: '700' }}>{n}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {tab === 'rem' ? (
        <View style={{ flex: 1 }}>
          <FlatList data={items} keyExtractor={i => i.id} renderItem={({ item }) => (
            <View style={s.row}>
              <Text style={s.time}>{item.t}</Text>
              <Text style={{ flex: 1 }}>{item.l}</Text>
              <Switch value={item.on} onValueChange={v => setItems(items.map(x => x.id === item.id ? { ...x, on: v } : x))} />
              <TouchableOpacity onPress={() => setItems(items.filter(x => x.id !== item.id))}><Text style={{ fontSize: 18, paddingLeft: 10 }}>✕</Text></TouchableOpacity>
            </View>
          )} />
          <View style={s.add}>
            <TextInput style={[s.in, { width: 80 }]} placeholder="HH:MM" value={nt} onChangeText={setNt} keyboardType="numbers-and-punctuation" />
            <TextInput style={[s.in, { flex: 1 }]} placeholder="e.g. Morning run" value={nl} onChangeText={setNl} />
            <TouchableOpacity style={s.btn} onPress={add}><Text style={{ color: '#fff', fontWeight: '700' }}>Add</Text></TouchableOpacity>
          </View>
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          <TextInput style={[s.in, { margin: 12 }]} placeholder="Search a dish…" value={q} onChangeText={setQ} />
          {sel && (
            <View style={s.res}>
              <Text style={{ fontSize: 16 }}>{sel[0]} ({sel[1]})</Text>
              <Text style={{ fontSize: 24, fontWeight: '800', color: ACC }}>{sel[2]} kcal</Text>
              <Text>Protein {sel[3]} g</Text>
            </View>
          )}
          <FlatList data={dishes} keyExtractor={d => d[0]} renderItem={({ item }) => (
            <TouchableOpacity style={s.row} onPress={() => setSel(item)}>
              <Text style={{ flex: 1 }}>{item[0]}</Text><Text style={{ color: '#888' }}>{item[1]}</Text>
            </TouchableOpacity>
          )} />
          <Text style={s.note}>Calories are approximate and vary with ghee/oil used.</Text>
        </View>
      )}
    </SafeAreaView>
  );
}

const ACC = '#ff5a1f';
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#f5f6fa', paddingTop: Platform.OS === 'android' ? 36 : 0 },
  h1: { fontSize: 28, fontWeight: '800', marginHorizontal: 16, marginVertical: 8 },
  tabs: { flexDirection: 'row', marginHorizontal: 12, gap: 8 },
  tab: { flex: 1, padding: 10, borderRadius: 10, backgroundColor: '#e5e7eb', alignItems: 'center' },
  tabOn: { backgroundColor: ACC },
  row: { flexDirection: 'row', alignItems: 'center', padding: 14, marginHorizontal: 12, marginTop: 8, backgroundColor: '#fff', borderRadius: 12 },
  time: { fontWeight: '800', width: 64 },
  add: { flexDirection: 'row', gap: 8, padding: 12 },
  in: { backgroundColor: '#fff', borderRadius: 10, padding: 10, borderWidth: 1, borderColor: '#e5e7eb' },
  btn: { backgroundColor: ACC, borderRadius: 10, paddingHorizontal: 16, justifyContent: 'center' },
  res: { backgroundColor: '#fff', marginHorizontal: 12, padding: 14, borderRadius: 12, borderWidth: 2, borderColor: ACC },
  note: { textAlign: 'center', color: '#888', padding: 8, fontSize: 12 },
});
