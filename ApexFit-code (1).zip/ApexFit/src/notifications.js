import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false }),
});

export async function setupNotifications() {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('reminders', {
      name: 'Reminders',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 250, 250],
    });
  }
  await Notifications.requestPermissionsAsync();
}

// Schedules every enabled reminder as a repeating daily notification.
export async function scheduleAll(items) {
  await Notifications.cancelAllScheduledNotificationsAsync();
  for (const r of items) {
    if (!r.on) continue;
    const [h, m] = r.t.split(':').map(Number);
    await Notifications.scheduleNotificationAsync({
      content: { title: 'ApexFit', body: r.l, sound: true },
      trigger: { hour: h, minute: m, repeats: true, channelId: 'reminders' },
    });
  }
}
