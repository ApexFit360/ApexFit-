export const DEFAULTS = [
  { id: '1', t: '06:30', l: 'Wake up and drink water', on: true },
  { id: '2', t: '07:00', l: 'Workout time', on: true },
  { id: '3', t: '09:00', l: 'Healthy breakfast', on: true },
  { id: '4', t: '13:00', l: 'Protein-rich lunch', on: true },
  { id: '5', t: '17:30', l: 'Walk and stretching', on: true },
  { id: '6', t: '22:30', l: 'Wind down for sleep', on: true },
];

// [name, serving, kcal, protein g]
export const DISHES = [
  ['Roti','1 medium',100,3],['Plain Paratha','1',260,5],['Aloo Paratha','1',300,6],['Rice (Chawal)','1 bowl',195,4],
  ['Dal Tadka','1 bowl',150,7],['Rajma','1 bowl',190,9],['Chole','1 bowl',210,9],['Paneer Butter Masala','1 bowl',300,12],
  ['Palak Paneer','1 bowl',230,11],['Chicken Curry','1 bowl',250,22],['Butter Chicken','1 bowl',300,20],
  ['Chicken Biryani','1 plate',450,20],['Veg Biryani','1 plate',350,8],['Idli','2 pcs',120,4],['Plain Dosa','1',130,3],
  ['Masala Dosa','1',250,5],['Sambar','1 bowl',90,4],['Poha','1 plate',250,5],['Upma','1 plate',230,5],['Samosa','1',260,4],
  ['Pav Bhaji','1 plate',400,9],['Vada Pav','1',290,6],['Chole Bhature','1 plate',450,12],['Dhokla','2 pcs',120,4],
  ['Khichdi','1 bowl',180,6],['Curd (Dahi)','1 bowl',90,4],['Kadhi','1 bowl',150,5],['Aloo Gobi','1 bowl',150,3],
  ['Bhindi Masala','1 bowl',120,3],['Egg Bhurji','2 eggs',200,12],['Besan Chilla','1',130,6],['Gulab Jamun','1',150,2],
  ['Jalebi','50 g',220,1],['Sweet Lassi','1 glass',200,6],['Sugar Tea (Chai)','1 cup',80,2],
];
