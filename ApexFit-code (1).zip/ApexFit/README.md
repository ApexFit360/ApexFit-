# ApexFit

Fitness app with daily reminders and an Indian dishes calorie guide.

## Structure
- `App.js` – app shell, tabs, storage
- `src/data.js` – default reminders and dishes
- `src/notifications.js` – daily notification scheduling
- `src/screens/RemindersScreen.js`, `DishesScreen.js` – the two screens
- `src/theme.js` – colors
- `assets/` – icon, adaptive icon, splash
- `app.json`, `package.json`, `babel.config.js` – project config
- `web/index.html` – web version (GitHub Pages)
