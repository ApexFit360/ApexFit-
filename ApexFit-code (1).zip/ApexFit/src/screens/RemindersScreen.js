import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, Switch, StyleSheet, Alert } from 'react-native';
import { ACC } from '../theme';

export default function RemindersScreen({ items, setItems }) {
  const [nt, setNt] = useState('');
  const [nl, setNl] = useState('');

  const add = () => {
    const ok = /^([01]?\d|2[0-3]):[0-5]\d$/.test(nt.trim());
    if (!ok || !nl.trim()) return Alert.alert('Invalid input', 'Use time like 18:30 and enter a name.');
    const [h, m] = nt.trim().split(':');
    setItems([...items, { id: String(Date.now()), t: h.padStart(2, '0') + ':' + m, l: nl.trim(), on: true }]);
    setNt('');
    setNl('');
  };

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={items}
        keyExtractor={i => i.id}
        renderItem={({ item }) => (
          <View style={s.row}>
            <Text style={s.time}>{item.t}</Text>
            <Text style={{ flex: 1 }}>{item.l}</Text>
            <Switch value={item.on} onValueChange={v => setItems(items.map(x => (x.id === item.id ? { ...x, on: v } : x)))} />
            <TouchableOpacity onPress={() => setItems(items.filter(x => x.id !== item.id))}>
              <Text style={{ fontSize: 18, paddingLeft: 10 }}>✕</Text>
            </TouchableOpacity>
          </View>
        )}
      />
      <View style={s.add}>
        <TextInput style={[s.in, { width: 80 }]} placeholder="HH:MM" value={nt} onChangeText={setNt} keyboardType="numbers-and-punctuation" />
        <TextInput style={[s.in, { flex: 1 }]} placeholder="e.g. Morning run" value={nl} onChangeText={setNl} />
        <TouchableOpacity style={s.btn} onPress={add}>
          <Text style={{ color: '#fff', fontWeight: '700' }}>Add</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', padding: 14, marginHorizontal: 12, marginTop: 8, backgroundColor: '#fff', borderRadius: 12 },
  time: { fontWeight: '800', width: 64 },
  add: { flexDirection: 'row', gap: 8, padding: 12 },
  in: { backgroundColor: '#fff', borderRadius: 10, padding: 10, borderWidth: 1, borderColor: '#e5e7eb' },
  btn: { backgroundColor: ACC, borderRadius: 10, paddingHorizontal: 16, justifyContent: 'center' },
});
