# ApexFit

Fitness app with daily reminders and an Indian dishes calorie guide.

- `App.js` – React Native (Expo) app
- `web/index.html` – web version (can be hosted on GitHub Pages)
