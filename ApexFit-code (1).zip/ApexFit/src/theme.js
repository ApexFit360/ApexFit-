export const ACC = '#ff5a1f';
